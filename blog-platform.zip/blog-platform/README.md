# Blog Platform

A full-stack blog application. Users sign up, log in, write blogs, browse all blogs, and open any blog on its own page. Data is stored in MongoDB.

![Blog Platform banner](./blog-banner.svg)

## Key Objectives

1. Connect the application with MongoDB.
2. Store user credentials and blog post data securely.
3. Retrieve and display all blogs from the database.
4. Create a page to view individual blog details.

## Features

- Sign up and log in, with passwords hashed using bcrypt
- JWT authentication for protected actions
- Create, edit and delete your own blogs (other users cannot change them)
- Home page listing all blogs, newest first
- Blog detail page at `/blog.html?id=<blog id>`
- Server-side validation and HTML escaping on every page

## Tech Stack

| Layer    | Technology                          |
|----------|-------------------------------------|
| Frontend | HTML, CSS, vanilla JavaScript       |
| Backend  | Node.js, Express                    |
| Database | MongoDB with Mongoose               |
| Auth     | bcryptjs, JSON Web Tokens           |

## Project Structure

```
blog-platform/
├── models/        User.js, Blog.js
├── routes/        auth.js, blogs.js
├── middleware/    auth.js (JWT check)
├── public/        index, blog, login, register, create pages + style.css + app.js
├── server.js
├── package.json
└── .env.example
```

## Getting Started

1. Install Node.js 18 or newer, and create a free MongoDB Atlas cluster (or run MongoDB locally).
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and fill in your values:

   ```env
   PORT=5000
   MONGO_URI=mongodb+srv://<user>:<password>@<cluster>.mongodb.net/blogdb
   JWT_SECRET=a_long_random_string
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open `http://localhost:5000`.

## API Endpoints

| Method | Endpoint             | Description             | Login needed |
|--------|----------------------|-------------------------|--------------|
| POST   | `/api/auth/register` | Create an account       | No           |
| POST   | `/api/auth/login`    | Log in, receive a token | No           |
| GET    | `/api/blogs`         | Get all blogs           | No           |
| GET    | `/api/blogs/:id`     | Get one blog            | No           |
| POST   | `/api/blogs`         | Create a blog           | Yes          |
| PUT    | `/api/blogs/:id`     | Update your blog        | Yes          |
| DELETE | `/api/blogs/:id`     | Delete your blog        | Yes          |

## Database Design

**users**: `name`, `email` (unique), `password` (bcrypt hash), `createdAt`

**blogs**: `title`, `content`, `author` (reference to users), `createdAt`

## Security Notes

- Passwords are hashed with bcrypt before saving and never returned by the API.
- Secrets live in `.env`, which is excluded from Git.
- Edit and delete routes check that the logged-in user owns the blog.
- User text is escaped before it is shown on a page.

## Future Improvements

- Comments and likes
- Image upload
- Search and tags
- Pagination

## Author

**Your Name**
[LinkedIn](https://linkedin.com/in/your-profile) · [GitHub](https://github.com/your-username)
