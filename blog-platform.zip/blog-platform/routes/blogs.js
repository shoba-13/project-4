const express = require('express');
const mongoose = require('mongoose');
const Blog = require('../models/Blog');
const auth = require('../middleware/auth');

const router = express.Router();
const validId = (id) => mongoose.Types.ObjectId.isValid(id);

// Get all blogs (newest first)
router.get('/', async (req, res) => {
  try {
    const blogs = await Blog.find().sort({ createdAt: -1 }).populate('author', 'name');
    res.json(blogs);
  } catch {
    res.status(500).json({ message: 'Could not load blogs' });
  }
});

// Get one blog
router.get('/:id', async (req, res) => {
  try {
    if (!validId(req.params.id)) return res.status(404).json({ message: 'Blog not found' });
    const blog = await Blog.findById(req.params.id).populate('author', 'name');
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    res.json(blog);
  } catch {
    res.status(500).json({ message: 'Could not load blog' });
  }
});

// Create blog
router.post('/', auth, async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!title || !content) return res.status(400).json({ message: 'Title and content are required' });
    const blog = await Blog.create({ title, content, author: req.user.id });
    res.status(201).json(blog);
  } catch {
    res.status(500).json({ message: 'Could not publish blog' });
  }
});

// Update own blog
router.put('/:id', auth, async (req, res) => {
  try {
    if (!validId(req.params.id)) return res.status(404).json({ message: 'Blog not found' });
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    if (String(blog.author) !== String(req.user.id)) return res.status(403).json({ message: 'You can only edit your own blogs' });

    const { title, content } = req.body;
    if (!title || !content) return res.status(400).json({ message: 'Title and content are required' });
    blog.title = title;
    blog.content = content;
    await blog.save();
    res.json(blog);
  } catch {
    res.status(500).json({ message: 'Could not update blog' });
  }
});

// Delete own blog
router.delete('/:id', auth, async (req, res) => {
  try {
    if (!validId(req.params.id)) return res.status(404).json({ message: 'Blog not found' });
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    if (String(blog.author) !== String(req.user.id)) return res.status(403).json({ message: 'You can only delete your own blogs' });
    await blog.deleteOne();
    res.json({ message: 'Blog deleted' });
  } catch {
    res.status(500).json({ message: 'Could not delete blog' });
  }
});

module.exports = router;
