// Shared helpers used by every page
const Auth = {
  get token() { return localStorage.getItem('token'); },
  get user() { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } },
  save(data) { localStorage.setItem('token', data.token); localStorage.setItem('user', JSON.stringify(data.user)); },
  clear() { localStorage.removeItem('token'); localStorage.removeItem('user'); }
};

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtDate(d) {
  return new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

async function api(path, method = 'GET', body) {
  const headers = { 'Content-Type': 'application/json' };
  if (Auth.token) headers.Authorization = 'Bearer ' + Auth.token;
  const res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}

function renderHeader() {
  const user = Auth.user;
  const links = user
    ? `<a href="/create.html">Write a blog</a><span>${esc(user.name)}</span><button id="logout">Log out</button>`
    : `<a href="/login.html">Log in</a><a href="/register.html">Sign up</a>`;
  document.getElementById('site-header').innerHTML =
    `<div class="bar"><a class="brand" href="/">Blog Platform</a><nav><a href="/">All blogs</a>${links}</nav></div>`;
  const out = document.getElementById('logout');
  if (out) out.onclick = () => { Auth.clear(); location.href = '/'; };
}

document.addEventListener('DOMContentLoaded', renderHeader);
